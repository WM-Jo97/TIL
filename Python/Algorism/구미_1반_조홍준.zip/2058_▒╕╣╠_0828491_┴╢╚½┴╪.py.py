number=list(input())
answer=int(number[0])+int(number[1])+int(number[2])+int(number[3])
print(answer)